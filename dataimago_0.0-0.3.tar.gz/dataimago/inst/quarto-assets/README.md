# dataimago CDN Distribution Assets

<!-- CDN Assets Badges -->
[![jsDelivr CDN](https://img.shields.io/badge/CDN-jsDelivr%20Ready-orange.svg)](https://cdn.jsdelivr.net/gh/dataimago/dataimago-rpkg@main/inst/quarto-assets/)
[![CSS Size](https://img.shields.io/badge/CSS%20Size-~6.1KB%20min-green.svg)](dataimago.min.css)
[![Design Tokens](https://img.shields.io/badge/Tokens-~1.8KB-blue.svg)](tokens.css)
[![SRI Hashes](https://img.shields.io/badge/Security-SRI%20Ready-red.svg)](#-security--reliability)
[![R Package Access](https://img.shields.io/badge/R%20Access-system.file()-purple.svg)](#r-package-access)
[![Production Ready](https://img.shields.io/badge/Status-Production%20Ready-brightgreen.svg)](#-file-inventory)

## 🎯 Purpose

This directory contains **CDN-ready CSS assets** that enable external projects to directly link to dataimago design system files via jsDelivr CDN. These files are **critical infrastructure** for the dataimago ecosystem.

> 📋 **See [../../ARCHITECTURE.md](../../ARCHITECTURE.md) for visual diagrams** showing how these CDN assets fit into the complete dataimago distribution system.

## ⚠️ CRITICAL WARNING

**NEVER DELETE THIS DIRECTORY OR ITS CONTENTS**

These files enable:
- 🌐 **CDN Distribution**: External projects can link directly via jsDelivr
- 📦 **R Package Access**: Users can find files with `system.file()`
- 🚀 **External Integration**: Third-party websites can use dataimago styling

## 📁 File Inventory

| File | Size | Purpose |
|------|------|---------|
| `dataimago.css` | ~6.1KB | **Unminified** CSS for development & debugging |
| `dataimago.min.css` | ~6.1KB | **Minified** CSS for production use |
| `tokens.css` | ~1.8KB | **Design tokens** as CSS custom properties |
| `ai_monogram_*.svg` | 920B ea | **AI monogram** navbar logos (4 theme variants) |
| `package_hex_logo_*.svg` | 1129B ea | **Hex logos** for package identity (4 theme variants) |

## 🌐 CDN Usage

### External Project Integration

```html
<!-- Production (minified CSS) -->
<link rel="stylesheet" 
      href="https://cdn.jsdelivr.net/gh/dataimago/dataimago-rpkg@v0.1.0/inst/quarto-assets/dataimago.min.css"
      integrity="sha384-[SRI-HASH]"
      crossorigin="anonymous">

<!-- Development (with comments) -->
<link rel="stylesheet" 
      href="https://cdn.jsdelivr.net/gh/dataimago/dataimago-rpkg@v0.1.0/inst/quarto-assets/dataimago.css">

<!-- Design tokens only -->
<link rel="stylesheet" 
      href="https://cdn.jsdelivr.net/gh/dataimago/dataimago-rpkg@v0.1.0/inst/quarto-assets/tokens.css">
```

### SVG Logo Integration

```html
<!-- AI Monogram (navbar branding) -->
<img src="https://cdn.jsdelivr.net/gh/dataimago/dataimago-rpkg@v0.1.0/inst/quarto-assets/ai_monogram_grey-light.svg" 
     alt="dataimago AI" class="navbar-logo light-mode">
<img src="https://cdn.jsdelivr.net/gh/dataimago/dataimago-rpkg@v0.1.0/inst/quarto-assets/ai_monogram_grey-dark.svg" 
     alt="dataimago AI" class="navbar-logo dark-mode">

<!-- Package Hex Logo (homepage/identity) -->
<img src="https://cdn.jsdelivr.net/gh/dataimago/dataimago-rpkg@v0.1.0/inst/quarto-assets/package_hex_logo_grey-light.svg" 
     alt="Package Logo" class="package-logo">
```

### Theme-Aware JavaScript Integration

```js
// Logo switching with theme awareness (corrected logic)
const logoElement = document.querySelector('.navbar-logo');
const currentTheme = document.documentElement.getAttribute('data-bs-theme');
const isHovered = /* hover state */;

// Correct mapping: grey (non-hover) -> color (hover) for each theme
const logoPath = `ai_monogram_${currentTheme === 'dark' ? 'grey-dark' : 'grey-light'}.svg`;
const hoverPath = `ai_monogram_${currentTheme === 'dark' ? 'light-dark' : 'dark-light'}.svg`;

logoElement.src = `https://cdn.jsdelivr.net/gh/dataimago/dataimago-rpkg@main/inst/quarto-assets/${isHovered ? hoverPath : logoPath}`;

// Note: Avoid CSS transitions on 'all' properties - use specific transitions:
// transition: max-height 0.25s ease-in-out, transform 0.25s ease-in-out;
```

### R Package Access

```r
# Find CSS files in installed package
css_path <- system.file("quarto-assets/dataimago.min.css", package = "dataimago")
tokens_path <- system.file("quarto-assets/tokens.css", package = "dataimago")

# Programmatic access
if (file.exists(css_path)) {
  cat("dataimago CSS available at:", css_path)
}
```

## 🔄 How These Files Are Generated

These files are **automatically generated** by the design system build process:

### CDN Distribution Flow

```mermaid
graph TB
    %% CDN Distribution Flow
    subgraph "Build System Output"
        BUILD[build_design_system]
        BUILD --> UI_DIST[ui/dist/<br/>Built Assets]
        UI_DIST --> DEV_CSS[dataimago.css<br/>6.1KB Unminified]
        UI_DIST --> PROD_CSS[dataimago.min.css<br/>6.1KB Minified]
        UI_DIST --> TOKENS[tokens.css<br/>1.8KB Variables]
    end

    subgraph "CDN Preparation"
        CDN_DIR[inst/quarto-assets/<br/>CDN Directory]
        SRI[SRI Hash Generation<br/>Security Verification]
        COPY[File Copy Process<br/>ui/dist → inst/quarto-assets]
    end

    subgraph "External Access Methods"
        JSDELIVR[jsDelivr CDN<br/>cdn.jsdelivr.net]
        R_ACCESS[R system.file<br/>Programmatic Access]
        DIRECT[Direct File Access<br/>Package Installation]
    end

    subgraph "Integration Examples"
        HTML[HTML Link Tags<br/>External Websites]
        QUARTO[Quarto _quarto.yml<br/>CSS Configuration]
        R_CODE[R Code<br/>Package Functions]
    end

    subgraph "Usage Patterns"
        PROD_USE[Production Sites<br/>Minified + SRI]
        DEV_USE[Development<br/>Unminified + Comments]
        TOKEN_USE[Custom Styling<br/>Variables Only]
    end

    subgraph "Security & Reliability"
        VERSIONING[Git Tag Versioning<br/>@v0.1.0 References]
        INTEGRITY[Subresource Integrity<br/>sha384- Hashes]
        FALLBACK[Local Fallbacks<br/>CDN Failure Protection]
    end

    %% Flow connections
    DEV_CSS --> COPY
    PROD_CSS --> COPY
    TOKENS --> COPY
    COPY --> CDN_DIR
    
    CDN_DIR --> SRI
    SRI --> JSDELIVR
    CDN_DIR --> R_ACCESS
    CDN_DIR --> DIRECT
    
    JSDELIVR --> HTML
    R_ACCESS --> R_CODE
    DIRECT --> QUARTO
    
    HTML --> PROD_USE
    HTML --> DEV_USE
    QUARTO --> TOKEN_USE
    R_CODE --> DEV_USE
    
    JSDELIVR --> VERSIONING
    VERSIONING --> INTEGRITY
    INTEGRITY --> FALLBACK

    %% Critical path highlighting
    BUILD --> CDN_DIR
    CDN_DIR --> JSDELIVR

    %% Styling
    classDef build fill:#3498db,stroke:#2c3e50,stroke-width:2px,color:#fff
    classDef cdn fill:#e74c3c,stroke:#c0392b,stroke-width:2px,color:#fff
    classDef access fill:#2ecc71,stroke:#27ae60,stroke-width:2px,color:#fff
    classDef integration fill:#f39c12,stroke:#e67e22,stroke-width:2px,color:#fff
    classDef usage fill:#9b59b6,stroke:#8e44ad,stroke-width:2px,color:#fff
    classDef security fill:#1abc9c,stroke:#16a085,stroke-width:2px,color:#fff

    class BUILD,UI_DIST,DEV_CSS,PROD_CSS,TOKENS build
    class CDN_DIR,SRI,COPY cdn
    class JSDELIVR,R_ACCESS,DIRECT access
    class HTML,QUARTO,R_CODE integration
    class PROD_USE,DEV_USE,TOKEN_USE usage
    class VERSIONING,INTEGRITY,FALLBACK security
```

### Build Process Details

```r
library(dataimago)

# 1. Ensure sophisticated UI workspace exists
create_ui_workspace()  # Preserves existing sophisticated system

# 2. Build all assets including CDN distribution
build_design_system(
  include_sri = TRUE,      # Generate security hashes
  update_extension = TRUE, # Update Quarto extension
  verbose = TRUE          # Show detailed progress
)

# 3. Files automatically copied from ui/dist/ to inst/quarto-assets/
```

## 🏗️ Build Process Flow

```
ui/src/tokens/*.json  →  Style Dictionary  →  CSS Custom Properties
ui/src/styles/*.scss  →  Sass Compiler    →  Compiled CSS
Compiled CSS         →  PostCSS          →  Minified & Optimized
Final CSS           →  Copy Process     →  inst/quarto-assets/
```

## 📋 Maintenance

### When to Update

Files are automatically updated when:
- Design tokens are modified (`ui/src/tokens/*.json`)
- SCSS source files are changed (`ui/src/styles/*.scss`)
- `build_design_system()` is executed

### Manual Updates

```r
# Force complete rebuild and distribution
build_design_system(force_rebuild = TRUE)

# Verify files were updated
list.files("inst/quarto-assets/", full.names = TRUE)
```

### Verification

```r
# Check file sizes (should be substantial)
file.info("inst/quarto-assets/dataimago.min.css")$size  # ~6KB
file.info("inst/quarto-assets/tokens.css")$size        # ~1.8KB

# Check content quality
readLines("inst/quarto-assets/tokens.css", n = 5)  # Should show CSS variables
```

## 🚨 Troubleshooting

### Problem: Files Are Missing
```r
# Regenerate from build system
build_design_system(force_rebuild = TRUE)
```

### Problem: Files Are Too Small (< 1KB)
This indicates a **minimal fallback system** was generated instead of the sophisticated build:
```r
# Check if sophisticated UI system exists
list.files("ui/src/", recursive = TRUE)  # Should show tokens/ and styles/

# If missing, restore from backup or repository
# Then rebuild
build_design_system(force_rebuild = TRUE)
```

### Problem: CDN Links Don't Work
- Check that the repository has been **tagged** for release
- Verify the **version number** in the CDN URL matches the tag
- Ensure files exist in the **specific tagged version**

## 🔗 Related Documentation

- `ui/README.md` - Complete design system documentation
- `R/design_system.R` - Build system functions
- Main `README.md` - Package architecture overview
- `CLAUDE.md` - Technical details for AI assistance

## 🎨 Design System Integration

These files are part of the larger dataimago design system:

- **Foundation**: Based on ethical AI principles (WCAG AA, reduced motion)
- **Token-Driven**: Generated from semantic JSON design tokens  
- **Multi-Platform**: Same source generates CSS, Tailwind presets, and more
- **Sophisticated**: Built with Style Dictionary + SCSS + PostCSS pipeline

### SVG Logo Architecture

The included SVG assets implement a sophisticated theme-aware logo system:

**Logo Variants:**
- **AI Monogram** (navbar branding): 4 variants for complete theme integration
  - `ai_monogram_grey-light.svg` → `ai_monogram_dark-light.svg` (light mode + hover)
  - `ai_monogram_grey-dark.svg` → `ai_monogram_light-dark.svg` (dark mode + hover)
- **Package Hex Logo** (identity): 4 variants for homepage/package branding
  - Same naming pattern with `package_hex_logo_` prefix

**Technical Quality:**
- **Optimized SVGs**: 920-1129 bytes with CSS mask-based typography
- **Smooth Transitions**: 0.3s hover animations with professional contrast switching
- **Universal Compatibility**: Works across all modern browsers and CDN systems
- **Theme Integration**: Perfect adaptation to Bootstrap 5.3+ theme system

---

*These assets enable external projects to adopt dataimago's ethical AI design principles through simple CSS links. They represent the visual expression of our philosophical commitment to emancipatory AI development.*
