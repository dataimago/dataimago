/**
 * custom-anchors.js - dataimago Design System
 * Built: 2025-08-28T17:04:31.428Z
 * Source: ui/src/js/custom-anchors.js
 */
// Apply anchor links to all headings (h1, h2, h3, etc.)
anchors.options = {
  placement: 'left',
  visible: 'hover'
};
anchors.add('h1, h2, h3, h4, h5, h6');
